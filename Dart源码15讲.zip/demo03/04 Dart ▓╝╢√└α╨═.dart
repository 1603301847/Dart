/*
Dart数据类型：布尔类型

bool 值true/false
 
*/



void main(){

  //1、bool

        // bool flag1=true;

        // print(flag1);

        // bool flag2=false;

        // print(flag2);


  //2、条件判断语句


      var flag=true;

      if(flag){
        print('真');
      }else{
        print('假');
      }


      // var a=123;

      // var b='123';

      // if(a==b){
      //   print('a=b');
      // }else{
      //    print('a!=b');
      // }


      var a=123;

      var b=123;

      if(a==b){
        print('a=b');
      }else{
         print('a!=b');
      }

}

