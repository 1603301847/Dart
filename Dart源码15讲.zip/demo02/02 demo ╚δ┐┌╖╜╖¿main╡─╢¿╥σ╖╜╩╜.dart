/*

 入口方法的两种定义方式


  main(){

    print('你好dart');
  }
  
*/

///这也是一个注释

//表示main方法没有返回值
void main(){
 print('你好dart');
}