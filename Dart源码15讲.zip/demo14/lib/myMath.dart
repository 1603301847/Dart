void getName(){
  print('张三');
}
void getAge(){
  print(20);
}
void getSex(){
  print('男');
}